@echo off
title IPTV Auto Update

set BASEDIR=%~dp0

echo Running IPTV refresh...
python "%BASEDIR%refresh_bg_m3u.py"

echo Uploading to GitHub...
python "%BASEDIR%push_to_github.py"

echo Done.