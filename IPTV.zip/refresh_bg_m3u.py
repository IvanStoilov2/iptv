import re
import time
import shutil
from urllib.parse import urlparse, parse_qs, unquote
from pathlib import Path
from playwright.sync_api import sync_playwright
from logger import setup_logger

logger = setup_logger("refresh")

BASE_DIR = Path(__file__).parent
SOURCE_M3U = BASE_DIR / "bg.m3u"
IPTV_DIR = BASE_DIR / "iptv"
IPTV_DIR.mkdir(exist_ok=True)
M3U_FILE = IPTV_DIR / "bg.m3u"

SITES = [
    "https://www.seir-sanduk.com/{channel_id}",
    "https://tv.otustanausta.com/{channel_id}",
]

CHANNEL_ID_RE = re.compile(
    r"/(hls|hlsfhd)/([^/?]+?)(?:/index\.m3u8|\.m3u8)",
    re.IGNORECASE
)

# ---------- helpers ----------

def copy_source_m3u():
    if not SOURCE_M3U.exists():
        raise FileNotFoundError("bg.m3u not found")

    shutil.copy2(SOURCE_M3U, M3U_FILE)
    logger.info("Copied bg.m3u to iptv/")

def extract_expiry(url: str | None):
    if not url:
        return None
    qs = parse_qs(urlparse(url).query)
    e = qs.get("e")
    if e and e[0].isdigit():
        return int(e[0])
    return None

def extract_glebul_from_mu(url: str) -> str | None:
    if "jwpltx.com" not in url:
        return None

    qs = parse_qs(urlparse(url).query)
    mu = qs.get("mu")
    if not mu:
        return None

    real = unquote(mu[0])
    if ".m3u8" in real and "glebul" in real:
        return real

    return None

def load_m3u():
    return M3U_FILE.read_text(encoding="utf-8")

def save_m3u(content):
    M3U_FILE.write_text(content, encoding="utf-8")

# ---------- playwright ----------

def refresh_channel(channel_id: str) -> str | None:
    logger.info(f"[CHANNEL] {channel_id}")

    for site in SITES:
        url = site.format(channel_id=channel_id)
        logger.info(f"[TRY] {url}")

        with sync_playwright() as p:
            browser = p.chromium.launch(
                headless=True,
                args=["--autoplay-policy=no-user-gesture-required"]
            )
            page = browser.new_page()

            found_url = None

            def on_response(resp):
                nonlocal found_url
                if found_url:
                    return  # вече имаме линк

                u = resp.url

                logger.debug(f"[RESP] {u}")

                # jwplayer telemetry
                if "jwpltx.com" in u:
                    real = extract_glebul_from_mu(u)
                    if real:
                        found_url = real
                        logger.info(f"[FOUND][jwpltx] {real}")
                        try:
                            page.stop()  #  спира зареждането
                        except:
                            pass
                        return

                # direct m3u8
                if ".m3u8" in u and "glebul" in u:
                    found_url = u
                    logger.info(f"[FOUND][direct] {u}")
                    try:
                        page.stop()  #  спира зареждането
                    except:
                        pass

            page.on("response", on_response)

            try:
                page.goto(
                    url,
                    timeout=15000,               # ⬅️ по-кратък timeout
                    wait_until="domcontentloaded"  # ⬅️ НЕ networkidle
                )

                # чакаме максимум 10 сек, но прекъсваме ако намерим линк
                for _ in range(20):  # 20 * 0.5 = 10 сек
                    if found_url:
                        break
                    time.sleep(0.5)

            except Exception as e:
                # ако вече имаме линк → игнорираме грешката
                if found_url:
                    logger.warning(f"[IGNORED ERROR] {e}")
                else:
                    logger.error(f"[ERROR] {url} → {e}")

            finally:
                browser.close()

            if found_url:
                return found_url

        logger.warning(f"[MISS] {url}")

    return None

# ---------- main logic ----------

def main():
    copy_source_m3u()

    content = load_m3u()
    lines = content.splitlines()
    updated = False

    for i, line in enumerate(lines):

        if ".m3u8" not in line:
            continue

        if "glebul" not in line:
            logger.debug(f"[SKIP non-glebul] {line}")
            continue

        m = CHANNEL_ID_RE.search(line)
        if not m:
            logger.warning(f"[NO MATCH] {line}")
            continue

        channel_id = m.group(2)
        old_url = line

        logger.info(f"[UPDATE] {channel_id}")

        new_url = refresh_channel(channel_id)

        if new_url and new_url != old_url:
            lines[i] = new_url
            updated = True

            exp = extract_expiry(new_url)
            if exp:
                logger.info(f"[EXPIRY] {time.ctime(exp)}")
            else:
                logger.info("[EXPIRY] none")
        else:
            logger.warning(f"[NO UPDATE] {channel_id}")

    if updated:
        save_m3u("\n".join(lines))
        logger.info("bg.m3u updated")
    else:
        logger.warning("No updates made (file unchanged)")

if __name__ == "__main__":
    main()