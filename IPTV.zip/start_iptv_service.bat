@echo off
REM Стартира IPTV Python service
python "%~dp0\iptv_service.py"