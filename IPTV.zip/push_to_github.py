import subprocess
import time
from pathlib import Path
from logger import setup_logger

logger = setup_logger("github")

IPTV_FOLDER = Path(__file__).parent / "iptv"
M3U_FILE = IPTV_FOLDER / "bg.m3u"

GIT_REPO = IPTV_FOLDER

def main():
    try:
        subprocess.run(["git", "-C", str(GIT_REPO), "add", str(M3U_FILE)], check=True)

        result = subprocess.run(
            ["git", "-C", str(GIT_REPO), "diff", "--cached", "--quiet"]
        )

        if result.returncode == 0:
            logger.info("No changes to commit")
            return

        commit_msg = f"Update M3U {time.strftime('%Y-%m-%d %H:%M:%S')}"

        subprocess.run(["git", "-C", str(GIT_REPO), "commit", "-m", commit_msg], check=True)
        subprocess.run(["git", "-C", str(GIT_REPO), "push"], check=True)

        logger.info("bg.m3u pushed to GitHub")

    except Exception as e:
        logger.error(f"Git error: {e}")

if __name__ == "__main__":
    main()