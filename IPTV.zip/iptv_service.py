import subprocess
import time
from pathlib import Path
from logger import setup_logger

logger = setup_logger("service")

BASE_DIR = Path(__file__).parent
UPDATE_BAT = BASE_DIR / "run_update.bat"

INTERVAL = 3600

def run_update():
    logger.info("[SERVICE] Starting update")

    try:
        subprocess.run([str(UPDATE_BAT)], check=True)
        logger.info("[SERVICE] Update finished")
    except subprocess.CalledProcessError as e:
        logger.error(f"[SERVICE] Update failed: {e}")

def main():
    logger.info("IPTV Service started")

    try:
        while True:
            run_update()
            logger.info(f"Sleeping {INTERVAL} seconds")
            time.sleep(INTERVAL)
    except KeyboardInterrupt:
        logger.info("Service stopped by user")

if __name__ == "__main__":
    main()